import { Email } from '../types';
import rbiLogo from '../assets/images/rbi_logo_1791695626607.jpg';

export const INITIAL_EMAILS: Email[] = [
  {
    id: 'email-rbi',
    sender: 'Reserve bank of India',
    senderEmail: 'finance@rbi.org.in',
    toEmail: 'r32071381@gmail.com',
    avatarImage: rbiLogo,
    avatarText: 'R',
    avatarColor: 'bg-[#0f4c81]',
    subject: 'Greetings for Crediting Amount',
    snippet: 'Dear Raghuraman Seetharaman We wish to inform you that, as per the relevant banking records...',
    body: `Dear Raghuraman Seetharaman

ATTN: HSBC BANK Ltd.
Acc No: 002196690127
IFSC Code: HSBC0400003
Reference / Ref No: SWIFT-GL-23092026-76901

We wish to inform you that, as per the relevant banking records, the amount of INR 13,500,000,000 (Indian Rupees One thousand three hundred and fifty crore Only) is reported to have been credited to your designated bank account.

The transaction is stated to be subject to applicable foreign remittance regulations, relevant provisions of Indian financial laws, and the necessary banking compliance and verification procedures.

You are advised to verify the credited amount directly with your bank and obtain an official account statement or transaction confirmation for your records. Any applicable regulatory requirements, documentation, or compliance formalities should be confirmed through the appropriate authorized banking channels.

For further clarification regarding the transaction, please contact your authorized bank representative.

Thank you for your attention and cooperation.

Yours sincerely,
Indranil Chakrabort
Financial Stability Department
Reserve Bank of India
3rd Floor, Amar Building
Sir P.M.Road, Mumbai-400 001`,
    time: '10:18 AM',
    unread: false,
    starred: false,
    category: 'primary',
    dateDetail: '12/10/2026, 10:18 AM',
  },
  {
    id: 'email-2',
    sender: 'KuCoin',
    senderEmail: 'no-reply@kucoin.com',
    avatarIcon: 'user',
    avatarColor: 'bg-[#94a3b8]',
    subject: 'Spot Deduction Coupon Received!',
    snippet: 'Spot Deduction Coupon Received! To...',
    body: `Dear KuCoin Trader,\n\nCongratulations! A new Spot Deduction Coupon worth 20 USDT has been credited to your Rewards Hub.\n\nCoupon Details:\n• Type: Spot Trading Fee Rebate (20% off)\n• Eligible pairs: BTC/USDT, ETH/USDT, SOL/USDT\n• Validity: 14 days from issue date\n\nLog in now to your KuCoin account and activate your voucher before expiry.\n\nKuCoin Global Community`,
    time: '12:34 AM',
    unread: true,
    starred: false,
    category: 'primary',
    dateDetail: 'Today, 12:34 AM',
  },
  {
    id: 'email-3',
    sender: 'Binance',
    senderEmail: 'notifications@binance.com',
    avatarText: 'B',
    avatarColor: 'bg-[#c084fc]',
    subject: 'Withdrawal Notice for PIVX Delistin...',
    snippet: 'Dear Binancian, Binance will be delisti...',
    body: `Dear Binancian,\n\nBinance will delist PIVX (Private Instant Verified Transaction) and cease trading on all PIVX spot trading pairs on 2026-10-25 03:00 (UTC).\n\nKey notes:\n1. All pending trade orders will be automatically cancelled after trading ceases in each respective pair.\n2. Withdrawals of PIVX tokens from Binance will be supported until 2026-11-25 03:00 (UTC).\n\nPlease ensure that you withdraw your tokens prior to this date to prevent any loss of assets.\n\nThanks for your support!\nThe Binance Team`,
    time: 'Oct 10',
    unread: true,
    starred: false,
    category: 'primary',
    dateDetail: 'Oct 10, 2026, 4:18 PM',
  },
  {
    id: 'email-4',
    sender: 'googleplay-...@google.com',
    senderEmail: 'googleplay-developer-support@google.com',
    avatarIcon: 'user',
    avatarColor: 'bg-[#94a3b8]',
    subject: 'Quarterly reminder about Google Play...',
    snippet: 'Review our Google Play Terms of Serv...',
    body: `Hello Google Play Developer,\n\nThis is a quarterly reminder to review our Google Play Developer Distribution Agreement and developer program policies.\n\nAs our ecosystem evolves, we continuously update policies regarding user privacy, Target API level requirements, and families policy compliance to ensure a safe experience for all users worldwide.\n\nPlease check your Play Console inbox to ensure all apps comply with current SDK requirements.\n\nThank you,\nThe Google Play Team`,
    time: 'Oct 10',
    unread: false,
    starred: false,
    category: 'primary',
    dateDetail: 'Oct 10, 2026, 11:22 AM',
  },
  {
    id: 'category-updates',
    sender: 'Updates',
    senderEmail: 'updates@google.com',
    avatarIcon: 'info',
    avatarColor: 'bg-[#f97316]',
    subject: 'ICICI Life Insurance — Get Rs ...',
    snippet: 'ICICI Life Insurance — Get Rs ...',
    body: `Updates summary:\n\n• ICICI Prudential Life: Guaranteed Return Plan with tax benefits.\n• GitHub: Dependabot security alert resolved for repository.\n• Google Cloud: Monthly billing statement for Project ID #8578b158.\n• AWS: Cost anomaly report indicates normal baseline spend.`,
    time: '',
    unread: true,
    starred: false,
    isCategoryRow: true,
    categoryType: 'updates',
    badge: {
      text: '99+ new',
      bgColor: 'bg-[#ff7a00]',
      textColor: 'text-white',
    },
    dateDetail: 'Recent updates',
  },
  {
    id: 'category-promotions',
    sender: 'Promotions',
    senderEmail: 'promotions@google.com',
    avatarIcon: 'tag',
    avatarColor: 'bg-[#10b981]',
    subject: 'Hatchable — Claude is conne...',
    snippet: 'Hatchable — Claude is conne...',
    body: `Promotions highlight:\n\n• Hatchable: Claude 3.5 Sonnet & Claude Opus are now natively connected to your workflow pipeline.\n• Zomato Gold: 40% off on weekend dining.\n• Coursera Plus: $100 discount on annual membership pass.\n• DigitalOcean: $200 free credit promotion active.`,
    time: '',
    unread: true,
    starred: false,
    isCategoryRow: true,
    categoryType: 'promotions',
    badge: {
      text: '99+ new',
      bgColor: 'bg-[#34d399]',
      textColor: 'text-white',
    },
    dateDetail: 'Special offers',
  },
  {
    id: 'email-7',
    sender: 'Regency Tiruttani by GRT Hotels...',
    senderEmail: 'feedback@grthotels.com',
    avatarText: 'R',
    avatarColor: 'bg-[#f97316]',
    subject: 'Did you enjoy your stay...',
    snippet: 'Did you enjoy your stay Email not displaying cor...',
    body: `Dear Guest,\n\nThank you for choosing Regency Tiruttani by GRT Hotels for your recent visit! We sincerely hope that our hospitality and accommodations lived up to your expectations.\n\nCould you please spare two minutes to rate your experience with us? Your valuable feedback helps our team provide even higher standards of comfort and culinary delight.\n\nWarm regards,\nGeneral Manager & Staff\nRegency Tiruttani by GRT Hotels`,
    time: 'Oct 10',
    unread: false,
    starred: false,
    category: 'primary',
    dateDetail: 'Oct 10, 2026, 8:45 AM',
  },
  {
    id: 'email-8',
    sender: 'GitHub',
    senderEmail: 'notifications@github.com',
    avatarText: 'G',
    avatarColor: 'bg-[#0f172a]',
    subject: '[Security alert] npm audit resolution complete',
    snippet: 'Dependabot successfully updated packages to v8.3.0...',
    body: `Dependabot resolved 0 vulnerabilities in repository.\n\nAll tests passed successfully on latest push to main branch.\n\nView commit details on GitHub.`,
    time: 'Oct 9',
    unread: false,
    starred: true,
    category: 'updates',
    dateDetail: 'Oct 9, 2026, 6:15 PM',
  },
  {
    id: 'email-9',
    sender: 'Google Cloud Platform',
    senderEmail: 'google-cloud-billing@google.com',
    avatarText: 'G',
    avatarColor: 'bg-[#3b82f6]',
    subject: 'Your Google Cloud Monthly Invoice #INV-2026-10',
    snippet: 'Your invoice for the billing period Sep 01 - Sep 30 is now available...',
    body: `Hello Karur,\n\nYour monthly statement for Google Cloud Platform is ready for download in Google Cloud Console.\n\nAccount: karur9552@gmail.com\nAmount: $0.00 (within Free Tier tier credits)\n\nThank you for choosing Google Cloud.`,
    time: 'Oct 8',
    unread: false,
    starred: false,
    category: 'updates',
    dateDetail: 'Oct 8, 2026, 3:00 AM',
  },
  {
    id: 'email-10',
    sender: 'Swiggy',
    senderEmail: 'deals@swiggy.in',
    avatarText: 'S',
    avatarColor: 'bg-[#ea580c]',
    subject: 'Craving Biryani? Get 50% OFF tonight!',
    snippet: 'Use code PARTY50 for instant savings on your dinner favorites...',
    body: `Hey Foodie,\n\nWeekend specials are live in your area! Order from top-rated restaurants with flat 50% off up to ₹120.\n\nOrder now on Swiggy!`,
    time: 'Oct 7',
    unread: false,
    starred: false,
    category: 'promotions',
    dateDetail: 'Oct 7, 2026, 7:15 PM',
  },
];
